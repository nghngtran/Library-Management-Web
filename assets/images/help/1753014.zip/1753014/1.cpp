#include <stddef.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

void readFile(string path, float*& a, int& n)
{
	fstream input(path, ios_base::in);
	input >> n;
	a = new float[n];

	for (int i = 0; i < n; i++)
	{
		input >> a[i];
	}

}

void ShakerSort(float *& a, int& n)
{
	int l = 0;
	int r = n - 1;
	int k = 0;
	while (l < r)
	{
		for (int i = l; i < r; i++)
		{
			if (a[i] > a[i + 1])
			{
				std::swap(a[i], a[i + 1]);
				k = i;
			}
		}
		r = k;
		for (int i = r; i > l; i--)
		{
			if (a[i] < a[i - 1])
			{
				std::swap(a[i], a[i - 1]);
				k = i;
			}
		}
		l = k;
	}
}

int main(void)
{
	int n;
	float *a;
	readFile("input_1.txt", a, n);
	
	ShakerSort(a, n);

	for (int i = 0; i < n; i++) {
		cout << a[i] << "\t";
	}
}