#include <iostream>
#include <string>
#include <fstream>
using namespace std;

void readFile(string path, float*& a, int& n)
{
	fstream input(path, ios_base::in);
	input >> n;
	a = new float[n];

	for (int i = 0; i < n; i++)
	{
		input >> a[i];
	}

}


void FindLargestSum(float *&a, int& n) {
	float localsum = -100000;
	float maxSum = -100000;

	int firstPosition = 0;
	int lastPosition = 0;
	int localstart = 0;

	for (int i = 0; i < n; i++) {
		if ((localsum + a[i]) < a[i]) {
			localsum = a[i];
			localstart = i;
		}
		else {
			localsum += a[i];
		}

		if (localsum > maxSum) {
			firstPosition = localstart;
			maxSum = localsum;
			lastPosition = i;
		}

	}
	for (int i = firstPosition; i <= lastPosition; i++) {
		cout << a[i] << " ";
	}

	cout << "\n" << maxSum;
}

void main() {
	int n;
	float* a;
	readFile("input_2.txt", a, n);

	FindLargestSum(a, n);

}