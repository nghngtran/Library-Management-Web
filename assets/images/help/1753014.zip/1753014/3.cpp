#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream> 

using namespace std;

vector<int> split(string str, char delimiter) {
	vector<int> internal;
	stringstream ss(str); 
	string tok;

	while (getline(ss, tok, delimiter)) {
		internal.push_back(atoi(tok.c_str()));
	}

	return internal;
}

bool readFile(const char* path, vector<int>& deno, int& total) {
	ifstream fin;

	fin.open(path);
	if (fin.is_open() == false) {
		return false;
	}
	string temp;
	int i = 0;
	while (getline(fin, temp)) {
		i++;
		if (i == 1) {
			deno = split(temp, ' ');
		}
		else if (i == 2) {
			total = atoi(temp.c_str());
		}
		else {
			return true;
		}
	}
	return true;
}

void countCurrency()
{	
	vector<int> deno;
	int total;
	readFile("input_3.txt",deno,total);
	int n = deno.size();
	int * noteCounter;
	noteCounter = new int[n];

	for (int i = 0; i < n; i++) {
		noteCounter[i] = 0;
	}


	for (int i = 0; i < n; i++) {
		if (total >= deno[i]) {
			noteCounter[i] = total / deno[i];
			total = total - noteCounter[i] * deno[i];
		}
	}

	for (int i = 0; i < n; i++) {
		if (noteCounter[i] != 0) {
			cout << deno[i] << " : "
				<< noteCounter[i] << endl;
		}
	}
}

int main() {
	countCurrency();
	
}